# Gun.lol Clone by npdk1 💻🔥
Chỉ cần chỉnh sửa mỗi file config.js rồi chạy index.html trên local là xong! 🎯

Còn muốn chạy trên hosting? Đẩy hết file lên, chỉnh config.js (link hình ảnh các kiểu) rồi up lên hosting – chạy ngon lành ngay! 🚀

Dùng web này để lấy mã màu hex cho config.js: htmlcolorcodes.com 🌈

## Không hỗ trợ cài đặt hay setup hộ đâu nha, tự mò đi nhé! 😎💾

# Gun.lol Clone by npdk1 💻⚡
Just tweak config.js and run index.html locally – boom, done! 🎯

For hosting? Upload all files, tweak config.js (image links and stuff), then push to your host – it’ll run smooth as hell! 🚀

Grab hex colors for config.js here: htmlcolorcodes.com 🌈

No install or setup help, figure it out yourself, coder! 😎💾